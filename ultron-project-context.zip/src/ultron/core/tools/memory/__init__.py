"""Memory package initialization."""
